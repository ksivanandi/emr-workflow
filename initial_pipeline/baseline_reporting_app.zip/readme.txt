##################################
Dash Baseline Report
last updated: 6.30.20
author: Andrew Malinow, PhD

Zip folder contains 2 folders and 1 .py file:
	-assets (contains .css template for the app)
	-data (.csv files to power the vizualizations in the app)
	-dashboard.py

The following packages are required:
	import dash
	import dash_core_components as dcc
	import dash_html_components as html
	import dash_bootstrap_components as dbc
	import pandas as pd
	import plotly.express as px
	import plotly.graph_objects as go
	import numpy as np
	from dash.dependencies import Input, Output
	import plotly.figure_factory as ff
	import base64



To run the app:
	1. unzip the contents to a directory on the Appliance.
	2. Open a command prompt and navigate to the directory
	3. run:
		python dashboard.py

Running the python script will start up the Dash server on the local machine on port 8050.
You will see the following message:
(base) C:\Users\amalinow>cd C:\Users\amalinow\Documents\dashapp

	(base) C:\Users\amalinow\Documents\dashapp>python dashboard.py
	Running on http://127.0.0.1:8050/
	Debugger PIN: 328-415-687
	 * Serving Flask app "dashboard" (lazy loading)
	 * Environment: production
	   WARNING: Do not use the development server in a production environment.
	   Use a production WSGI server instead.
	 * Debug mode: on
	Running on http://127.0.0.1:8050/
	Debugger PIN: 355-271-780
